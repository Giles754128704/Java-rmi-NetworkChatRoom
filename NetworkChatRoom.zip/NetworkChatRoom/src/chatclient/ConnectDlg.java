package chatclient;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

// ���ӶԻ�
public class ConnectDlg extends JDialog implements PropertyChangeListener {
	private JTextField serverAddrField;
	private JTextField userNameField;
	private JOptionPane optionPane;
	private String serverAddr, userName;
	private int value = -1;
	
	public ConnectDlg(Frame frame) {
		super(frame, "����", true);
		serverAddrField = new JTextField(15);
		serverAddrField.setActionCommand("localhost:3333");
		userNameField = new JTextField(20);
		Object[] array = { "��������ַ(Ĭ�ϵ�ַΪlocalhost:1099)", serverAddrField, "�û���", userNameField };
		optionPane = new JOptionPane(array, JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_CANCEL_OPTION);
		setContentPane(optionPane);
		
		optionPane.addPropertyChangeListener(this);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				setVisible(false);
			}
		});
	}
	
	public void propertyChange(PropertyChangeEvent e) {
		String prop = e.getPropertyName();
		if (isVisible() && (e.getSource() == optionPane) && (JOptionPane.VALUE_PROPERTY.equals(prop) ||
				JOptionPane.INPUT_VALUE_PROPERTY.equals(prop))) {
			if (optionPane.getValue() == JOptionPane.UNINITIALIZED_VALUE) {
				return;
			}
			value = ((Integer) optionPane.getValue()).intValue();
			optionPane.setValue(JOptionPane.UNINITIALIZED_VALUE);
			if (value == JOptionPane.OK_OPTION) {
				if ("".equals(serverAddrField.getText()) || "".equals(userNameField.getText())) {
					JOptionPane.showMessageDialog(this, "�����û������������ַ");
					if ("".equals(serverAddrField.getText()))
						serverAddrField.requestFocus();
					else if ("".equals(userNameField.getText()))
						userNameField.requestFocus();
				} else {
					setServerAddr(serverAddrField.getText());
					setUserName(userNameField.getText());
					setVisible(false);
				}
			} else {
				setVisible(false);
			}
		}
	}

	public String getServerAddr() {
		return serverAddr;
	}

	public void setServerAddr(String serverAddr) {
		this.serverAddr = serverAddr;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getValue() {
		return value;
	}
	
}
